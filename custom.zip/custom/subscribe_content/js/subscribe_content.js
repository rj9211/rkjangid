Drupal.behaviors.subscribe_content = {
    attach: function (context, settings) {
      jQuery('#error_message', context).keyup(function () {
        // $(this).next('ul').toggle('show');
        var mail = jQuery('#error_message').val();
        var position = mail.search("@");
        if(position < 0)
        {
          jQuery(".show-mail").notify("Mail Should Contains @",'error');
        }
        else
        {
          // jQuery('.show-mail').html('<span>'+mail+'</span>'); 
          jQuery(".show-mail").notify(mail,'success');
        }
        
      });
      // jQuery('.reset')
      jQuery('.reset').on('click',function(){
        jQuery('.filter-form').trigger("reset");
      });
    // var interval = drupalSettings.notifybar.interval;
    // var period = drupalSettings.notifybar.period;
    // console.log(interval);
    // console.log(period);

    }
  };