<?php

namespace Drupal\subscribe_content\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\Core\Routing;
use Drupal\Core\Link;

/**
 * Class DeleteSubscriptionController.
 */
class DeleteSubscriptionController extends ControllerBase {

  /**
   * Deletesubscription.
   *
   * @return string
   *   Return Hello string.
   */
  public function deleteSubscription($id) 
  {
    $deleteButton = Url::fromRoute('subscribe_content.subscription.edit',['id'=>$id],[]);
    $deleteButton = Link::fromTextAndUrl(t('Delete'),$deleteButton);
    $deleteButton = $deleteButton->toRenderable();
    // $cancelButton = Url::fromRoute('subscribe_content.subscription.edit',['id'=>$res->id],[]);
    return [
      '#type'         => 'markup',
      '#markup'       => $this->t('Do you want to delete %id ?', ['%id' => $id ]),
    ];
  }
}
