<?php

namespace Drupal\subscribe_content\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Routing;
use Drupal\Core\Link;
use Drupal\Core\Asset\LibraryDiscoveryParser;

/**
 * Class SubscribeContentController.
 */
class SubscribeContentController extends ControllerBase {

  /**
   * Subscribecontent.
   *
   * @return string
   *   Return Hello string.
   */
  public function subscribeContent() {
    $fields   = array('name'=>'name','email'=>'email');
    $query    = \Drupal::database()->select('subscribe_content', 'sc');
    $query->fields('sc', ['id','name','email']);
    $query->condition('isDeleted',0);
    if(\Drupal::request()->query->get('email'))
    {
      $email = \Drupal::request()->query->get('email');
      $query->condition('email',$email);
    }

    $form['form'] = $this->formBuilder()->getForm('Drupal\subscribe_content\Form\FilterForm');
    $pager = $query->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(10);
    $results  = $pager->execute()->fetchAll();
    $data = array();

    $header = [
      'id'      => t('ID'),
      'name'    => t('Name'),
      'email'   => t('E-mail'),
      'edit'    => t('Edit'),
      'delete'  => t('Delete'),
    ];

    foreach($results as $row => $res)
    {
      $edit_lnk            = Url::fromRoute('subscribe_content.subscription.edit',['id'=>$res->id],[]);
	    $delete_lnk          = Url::fromRoute('subscribe_content.delete_subscription_form',['id'=>$res->id],[]);
      $edit_link           = Link::fromTextAndUrl(t('Edit'),$edit_lnk);
      $delete_link         = Link::fromTextAndUrl(t('Delete'),$delete_lnk);
      $edit_link           = $edit_link->toRenderable();
      $delete_link         = $delete_link->toRenderable();

      $add_content         = Url::fromRoute('subscribe_content.subscription.add');
      $add_content_link    = Link::fromTextAndUrl(t('Add Content'),$add_content);
      $add_content_link    = $add_content_link->toRenderable();

      $mainLink = t('@linkApprove  @linkReject', array('@linkApprove' => $edit_link, '@linkReject' => $delete_link,'@linkReject' => $add_content_link));

      // for theme use twig
      // $edit    = '/edit/subscription/'.$res->id;
      // $delete  = '/delete/subscription/'.$res->id;

      $data[$res->id] = [
        'id'      => $res->id,
        'name'    => $res->name,
        'email'   => $res->email,
        'edit'    => render($delete_link),
		    'delete'  =>render($edit_link),
      ];
    }
    $form['table'] = [
      '#type'   => 'table',
      '#header' => $header,
      '#rows'   => $data,
    ];
    $form['pager'] = [
      '#type' => 'pager',
    ];
  
    // pass array to twig
    // $build = [
    //   '#theme' => 'subscribe_content',
    //   '#header' => $header,
    //   '#rows'   => $data,
    // ];
    return $form;
  }
}