<?php

namespace Drupal\subscribe_content\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use \Drupal\Core\Database\Connection;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Url;
use Drupal\Core\Routing;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Ajax\AlertCommand;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\Core\Form\FormState;
use Drupal\Core\Link;

// use Drupal\Core\Form\ConfirmFormBase;
/**
 * Class SubscriptionForm.
 */
class SubscriptionForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'subscription_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $uri_segments = explode('/', $uri_path);
    $mail = '';
    if($uri_segments[1] == 'edit' || $uri_segments[1] == 'delete')
    {
      $segment = $uri_segments[3];
      if($segment != '')
      {
        $query = \Drupal::database()->select('subscribe_content', 'sc');
        $query->fields('sc', ['id','name','email']);
        $query->condition('id',$segment);
        $results = $query->execute()->fetchAll();

        foreach($results as $row => $res)
        {
          $mail = $res->email;
        }
      }
    }

    if($uri_segments[1] != 'delete')
    {
      $form['#prefix'] = '<div id="my-form-wrapper-id">';
      $form['#suffix'] = '</div>';
      $form['e_mail'] = [
        '#type' => 'email',
        '#title' => $this->t('E-Mail'),
        '#weight' => '0',
        '#required' => true,
        '#default_value' => ($mail != '')?t($mail):'',
      ];
      $form['submit'] = [
        '#type' => 'submit',
        '#value' => $this->t('Save Changes'),
        '#attributes' => [
            'class' => [
                'btn',
                'btn-md',
                'btn-primary',
                'use-ajax-submit'
            ]
        ],
        '#ajax' => [
            'wrapper' => 'my-form-wrapper-id',
        ]
      ];
      $form['link'] = [
        '#title' => t('Content'),
        '#type' => 'link',
        '#attributes' => [
          'class' => [
              'btn',
              'btn-md',
              'btn-primary',
          ]
      ],
      '#url' => Url::fromRoute('subscribe_content.subscribe_content_controller_subscribeContent'),
      ];
      return $form;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    foreach ($form_state->getValues() as $key => $value) {
      // @TODO: Validate fields.
    }
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */

  public function submitForm(array &$form, FormStateInterface $form_state) {

    $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $uri_segments = explode('/', $uri_path);
    $segment = '';
    if($uri_segments[1] == 'edit' || $uri_segments[1] == 'delete')
    {
      $segment = $uri_segments[3];
    }
    $base_path = Url::fromRoute('<front>', [], ['absolute' => TRUE])->toString();
    $current_url = Url::fromRoute('<current>');
    $path = $current_url->toString();
    $page = $base_path.$path;
    
    $request     = \Drupal::request();
    $route_match = \Drupal::routeMatch();
    $title       = \Drupal::service('title_resolver')->getTitle($request, $route_match->getRouteObject());

    $email  = $form_state->getValue('e_mail');
    $fields = array('content_id' => 1, 'name' => $title, 'url' => $page , 'email' => $email,'isDeleted' => 0);
    if(!empty($segment) && $segment != '' && $uri_segments[1] != 'delete')
    {
      $query = \Drupal::database();
      $query->update('subscribe_content')->fields($fields)->condition('id', $segment)->execute();
      if($query != '' && !empty($query))
      {
        $mailManager       = \Drupal::service('plugin.manager.mail');
        $module            = 'subscribe_content';
        $key               = 'general_mail';
        $to                = $email;
        $params['message'] = "You have subscribed our service. Page : ".$page." Title : ".$title;
        $params['subject'] = "Mail subject";
        $langcode          = \Drupal::currentUser()->getPreferredLangcode();
        $send              = true;

        $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);

        if ($result['result'] !== true) {
          \Drupal::messenger()->addMessage(t('There was a problem sending your message and it was not sent.'), 'error');
          \Drupal::messenger()->addMessage(t("Your subscription has been saved for this page : ".$page));
        }
        else {
          \Drupal::messenger()->addMessage(t('Your message has been sent.'));
          \Drupal::messenger()->addMessage(t("Your subscription has been saved for this page : ".$page));
        }
      }  
    }
    elseif($segment == '' && $uri_segments[1] != 'delete')
    {
      $db = \Drupal::database()->insert('subscribe_content')
            ->fields(['content_id', 'name', 'url' , 'email', 'isDeleted'])
            ->values($fields)
            ->execute();
      if($db > 0)
      {
        $mailManager       = \Drupal::service('plugin.manager.mail');
        $module            = 'subscribe_content';
        $key               = 'general_mail';
        $to                = $email;
        $params['message'] = "You have subscribed our service. Page : ".$page." Title : ".$title;
        $params['subject'] = "Mail subject";
        $langcode          = \Drupal::currentUser()->getPreferredLangcode();
        $send              = true;

        $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);

        if ($result['result'] !== true) {
          \Drupal::messenger()->addMessage(t('There was a problem sending your message and it was not sent.'), 'error');
          \Drupal::messenger()->addMessage(t("Your subscription has been saved for this page : ".$page));
        }
        else {
          \Drupal::messenger()->addMessage(t('Your message has been sent.'));
          \Drupal::messenger()->addMessage(t("Your subscription has been saved for this page : ".$page));
        }
      }
    }    
  }
}
