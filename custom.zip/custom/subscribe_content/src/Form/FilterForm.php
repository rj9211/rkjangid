<?php

namespace Drupal\subscribe_content\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Render\HtmlResponseAttachmentsProcessor;

/**
 * Class FilterForm.
 */
class FilterForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'filter_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['filters'] = [
      '#type'  => 'fieldset',
      '#title' => $this->t('Filter'),
      '#open'  => true,
    ];
    $form['filters']['#prefix'] = '<div id="my-form-wrapper-id">';
    $form['filters']['#suffix'] = '</div>';

    $form['#attached']['library'] = 'subscribe_content/subscribe_content.tree';

    
    $form['filters']['email'] = [
        '#title'         => 'Email',
        '#type'          => 'search',
        '#attributes' => [
          'id' => 'error_message',
        ],
    ];
    $form['filters']['actions'] = [
        '#type'       => 'actions'
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Filter'),
      '#attributes' => [
          'class' => [
              'btn',
              'btn-md',
              'btn-primary',
          ]
      ],
    ];
    $form['action']['reset'] = [
      '#type' => 'submit',
      '#title' => t('Reset'),
      '#value' => $this->t('Reset'),
      '#attributes' => [
          'class' => [
              'btn',
              'btn-md reset',
              'btn-primary',
          ],
      ],
      '#ajax' => [
        'effecy' => 'fade',
        'callback' => '::resetForm',
        'wrapper' => 'my-form',
      ],
    ];
    $form['filters']['message'] = [
      '#prefix' => '<div class="show-mail">',
      '#subfix' => '</div>'
    ];
  
    return $form;
  }

  /**
   * {@inheritdoc}
   */

  function resetForm($form, &$form_state) {
    $form_state['rebuild'] = FALSE;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    $pos = strpos($form_state->getValue('email'),'@');
    if($pos < 0)
    {
      $form_state->setErrorByName('submitted][email', t('The email address appears to be invalid.'));
    }
    else
    {
      \Drupal::messenger()->addMessage(t('Mail Verified.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Display result.
	  $email = $form_state->getValue('email');
    $url = \Drupal\Core\Url::fromRoute('subscribe_content.subscription.list')
          ->setRouteParameters(array('email'=>$email));
    $form_state->setRedirectUrl($url); 
  }
}
