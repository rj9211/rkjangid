<?php

namespace Drupal\subscribe_content\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Url;
use Drupal\Core\Render\Element;

class DeleteSubscriptionForm extends ConfirmFormBase {

  /**
   * ID of the item to delete.
   *
   * @var int
   */
  protected $id;

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, string $id = NULL) {
    $this->id = $id;
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) 
  {
    $query = \Drupal::database();
    $query->delete('subscribe_content')
                ->condition('id',$this->id)
               ->execute();
    \Drupal::messenger()->addMessage(t('Subscription has been deleted.'), 'success');
    $form_state->setRedirect('subscribe_content.subscription.list');
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() : string {
    return "delete_subscription_form";
  }

  /**
   * {@inheritdoc}
   */
  public function getCancelUrl() {
    return new Url('subscribe_content.subscription.list');
  }

  /**
   * {@inheritdoc}
   */
  public function getQuestion() {
    return $this->t('Do you want to delete %id?', ['%id' => $this->id]);
  }

}
