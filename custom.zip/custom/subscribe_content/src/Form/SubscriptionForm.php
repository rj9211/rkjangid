<?php

namespace Drupal\subscribe_content\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use \Drupal\Core\Database\Connection;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Url;
use Drupal\Core\Routing;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Ajax\AlertCommand;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\Core\Form\FormState;
use Drupal\Core\Link;

// use Drupal\Core\Form\ConfirmFormBase;
/**
 * Class SubscriptionForm.
 */
class SubscriptionForm extends FormBase 
{

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'subscription_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) 
  {
    $mail = '';
    $path = \Drupal::request()->getpathInfo();
    $arg  = explode('/',$path);
    if(count($arg) > 4)
    {
      $id   = $arg[4];
      $query = \Drupal::database()->select('subscribe_content', 'sc');
      $query->fields('sc', ['id','name','email']);
      $query->condition('id',$id);
      $results = $query->execute()->fetchAll();

      foreach($results as $row => $res)
      {
        $mail = $res->email;
      }
    } 
    $form['#attached']['library'] = 'subscribe_content/subscribe_content.tree';

    $form['#prefix'] = '<div id="my-form-wrapper-id">';
    $form['#suffix'] = '</div>';
    $form['message'] = [
      '#prefix' => '<div class="show-mail">',
      '#subfix' => '</div>'
    ];
    $form['e_mail'] = [
      '#type' => 'email',
      '#title' => $this->t('E-Mail'),
      '#weight' => '0',
      '#required' => true,
      '#attributes' => [
        'id' => 'error_message',
      ],
      '#default_value' => ($mail != '')?t($mail):'',
    ];
    
    
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save Changes'),
      '#attributes' => [
          'class' => [
              'btn',
              'btn-md',
              'btn-primary',
              'use-ajax-submit'
          ]
      ],
      '#ajax' => [
          'wrapper' => 'my-form-wrapper-id',
          // 'event'   => 'click',
          'effect'  => 'fade'
      ]
    ];
    $form['link'] = [
      '#title' => t('Content'),
      '#type' => 'link',
      '#attributes' => [
        'class' => [
            'btn',
            'btn-md',
            'btn-primary',
        ]
    ],
    '#url' => Url::fromRoute('subscribe_content.subscription.list'),
    ];
    
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) 
  {
    foreach ($form_state->getValues() as $key => $value) {
      // @TODO: Validate fields.
    }
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */

  public function submitForm(array &$form, FormStateInterface $form_state) 
  {
    // Get ID Parameter from URL while edit content

    $path = \Drupal::request()->getpathInfo();
    $arg  = explode('/',$path);
    $id = '';
    if($arg != '')
    {
      $id   = $arg[4];
    } 

    // Get Current Page URL 
    $base_path = Url::fromRoute('<front>', [], ['absolute' => TRUE])->toString();
    $current_url = Url::fromRoute('<current>');
    $path = $current_url->toString();
    $CurrentPageUrl = $base_path.$path;

    // Get Current Page Title
    $request     = \Drupal::request();
    $route_match = \Drupal::routeMatch();
    $title       = \Drupal::service('title_resolver')->getTitle($request, $route_match->getRouteObject());

    // Get Form Fields Value
    $email  = $form_state->getValue('e_mail');

    // Fields Array For Insert Query
    $fields = array('content_id' => 1, 'name' => $title, 'url' => $CurrentPageUrl , 'email' => $email,'isDeleted' => 0);

    // Insert Query
    if(!empty($email) && $id == '')
    {
      $db = \Drupal::database()->insert('subscribe_content')
            ->fields(['content_id', 'name', 'url' , 'email', 'isDeleted'])
            ->values($fields)
            ->execute();
      if($db > 0)
      {
        $mailManager       = \Drupal::service('plugin.manager.mail');
        $module            = 'subscribe_content';
        $key               = 'general_mail';
        $to                = $email;
        $params['message'] = "You have subscribed our service. Page : ".$CurrentPageUrl." Title : ".$title;
        $params['subject'] = "Mail subject";
        $langcode          = \Drupal::currentUser()->getPreferredLangcode();
        $send              = true;

        $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);

        if ($result['result'] !== true) 
        {
          \Drupal::messenger()->addMessage(t('There was a problem sending your message and it was not sent.'), 'error');
          \Drupal::messenger()->addMessage(t("Your subscription has been saved for this page : ".$title));
        }
        else 
        {
          \Drupal::messenger()->addMessage(t('Your message has been sent.'));
          \Drupal::messenger()->addMessage(t("Your subscription has been saved for this page : ".$title));
        }
      }
    }
    elseif(!empty($email) && $id != '')
    {
      $query = \Drupal::database();
      $query->update('subscribe_content')->fields($fields)->condition('id', $id)->execute();
      if($query != '' && !empty($query))
      {
        $mailManager       = \Drupal::service('plugin.manager.mail');
        $module            = 'subscribe_content';
        $key               = 'general_mail';
        $to                = $email;
        $params['message'] = "You have subscribed our service. Page : ".$CurrentPageUrl." Title : ".$title;
        $params['subject'] = "Mail subject";
        $langcode          = \Drupal::currentUser()->getPreferredLangcode();
        $send              = true;

        $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);

        if ($result['result'] !== true) {
          \Drupal::messenger()->addMessage(t('There was a problem sending your message and it was not sent.'), 'error');
          \Drupal::messenger()->addMessage(t("Your subscription has been Updated for this page : ".$CurrentPageUrl));
        }
        else {
          \Drupal::messenger()->addMessage(t('Your message has been sent.'));
          \Drupal::messenger()->addMessage(t("Your subscription has been Updated for this page : ".$CurrentPageUrl));
        }
      }
    }
    // $url      = new Url('subscribe_content.subscription.list');
    // $response = new RedirectResponse($url->toString());
    // $response->send();
  }
}
